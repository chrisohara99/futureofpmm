// netlify/functions/save-survey.js
var SUPABASE_URL = "https://yyqzkczutlidhgyiyawc.supabase.co";
var SUPABASE_SERVICE_KEY = process.env.SUPABASE_SERVICE_KEY;
exports.handler = async (event) => {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Content-Type": "application/json"
  };
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 200, headers, body: "" };
  }
  try {
    const data = JSON.parse(event.body || "{}");
    const {
      value_rating,
      newsletter_rating,
      content_rating,
      assessments_rating,
      labs_rating,
      presentation_rating,
      quiz_difficulty,
      top_learning,
      most_useful_unit,
      applying_at_work,
      improvements,
      nps,
      email,
      from_unit,
      quiz_score
    } = data;
    if (!value_rating || !top_learning || !most_useful_unit || !applying_at_work || nps === void 0) {
      return { statusCode: 400, headers, body: JSON.stringify({ error: "Missing required fields" }) };
    }
    const res = await fetch(`${SUPABASE_URL}/rest/v1/survey_responses`, {
      method: "POST",
      headers: {
        "apikey": SUPABASE_SERVICE_KEY,
        "Authorization": `Bearer ${SUPABASE_SERVICE_KEY}`,
        "Content-Type": "application/json",
        "Prefer": "return=minimal"
      },
      body: JSON.stringify({
        value_rating,
        newsletter_rating: newsletter_rating || null,
        content_rating: content_rating || null,
        assessments_rating: assessments_rating || null,
        labs_rating: labs_rating || null,
        presentation_rating: presentation_rating || null,
        quiz_difficulty: quiz_difficulty || null,
        top_learning,
        most_useful_unit,
        applying_at_work,
        improvements,
        nps,
        email: email || null,
        week_number: getWeekNumber()
        // NOTE: from_unit and triggered_quiz_score columns need to be added to production DB
        // Run: ALTER TABLE survey_responses ADD COLUMN from_unit TEXT;
        // Run: ALTER TABLE survey_responses ADD COLUMN triggered_quiz_score INTEGER;
      })
    });
    if (!res.ok) {
      const err = await res.text();
      console.error("Survey save error:", err);
      return { statusCode: 500, headers, body: JSON.stringify({ error: "Failed to save survey" }) };
    }
    return { statusCode: 200, headers, body: JSON.stringify({ success: true }) };
  } catch (err) {
    console.error("Error:", err);
    return { statusCode: 500, headers, body: JSON.stringify({ error: "Server error" }) };
  }
};
function getWeekNumber() {
  const now = /* @__PURE__ */ new Date();
  const start = new Date(now.getFullYear(), 0, 1);
  const diff = now - start;
  const oneWeek = 6048e5;
  return Math.ceil(diff / oneWeek);
}
