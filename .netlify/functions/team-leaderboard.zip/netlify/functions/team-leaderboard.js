// netlify/functions/team-leaderboard.js
var SUPABASE_URL = "https://yyqzkczutlidhgyiyawc.supabase.co";
var SUPABASE_SERVICE_KEY = process.env.SUPABASE_SERVICE_KEY;
var ACTIVE_UNITS = ["unit-01", "unit-02", "unit-03", "unit-04", "unit-05", "unit-06", "unit-07", "unit-08"];
var TEAM_EMAILS = [
  "a.naji@sap.com",
  "axel.schuller@sap.com",
  "brian.raver@sap.com",
  "cathy.citarelli@sap.com",
  "corrie.birkeness@sap.com",
  "daniel.dukes@sap.com",
  "jacob.brass@sap.com",
  "jose.chicas@sap.com",
  "josh.ledbetter@sap.com",
  "justin.ham@sap.com",
  // "kaiser.larsen@sap.com",  // Removed - interim leader replacing Dan
  "kara.reed@sap.com",
  "karsten.ruf@sap.com",
  "katryn.cheng@sap.com",
  "kendall.dignam@sap.com",
  "kuba.kufel@sap.com",
  "lauren.wong@sap.com",
  "liam.clarke@sap.com",
  "matthew.lyman@sap.com",
  "max.law@sap.com",
  "megan.hoy@sap.com",
  "neil.whitehead@sap.com",
  "olivier.duvelleroy@sap.com",
  "orla.cullen@sap.com",
  "pam.barrowcliffe@sap.com",
  "saely.espaillat@sap.com",
  "savannah.voll@sap.com",
  "scott.mackenzie@sap.com",
  "sim.patara@sap.com",
  "stuart.giles@sap.com",
  "tara.rogers@sap.com",
  "teuta.elezaj@sap.com",
  "thierry.audas@sap.com",
  "tiffany.baker@sap.com",
  "tony.truong@sap.com",
  "venkata.giduthuri@sap.com",
  "yanhong.tong@sap.com"
];
exports.handler = async (event) => {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Content-Type": "application/json"
  };
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 200, headers, body: "" };
  }
  try {
    const emailList = TEAM_EMAILS.map((e) => `"${e}"`).join(",");
    const profilesRes = await fetch(
      `${SUPABASE_URL}/rest/v1/profiles?email=in.(${emailList})&select=id,first_name,last_name,email,created_at`,
      {
        headers: {
          "apikey": SUPABASE_SERVICE_KEY,
          "Authorization": `Bearer ${SUPABASE_SERVICE_KEY}`
        }
      }
    );
    let profiles = await profilesRes.json();
    if (profiles.error || profiles.message) {
      console.error("Supabase error:", profiles);
      return { statusCode: 500, headers, body: JSON.stringify({ error: "Database error", details: profiles }) };
    }
    const userIds = profiles.map((p) => p.id);
    if (userIds.length === 0) {
      return { statusCode: 200, headers, body: JSON.stringify({ leaderboard: [] }) };
    }
    const userIdList = userIds.map((id) => `"${id}"`).join(",");
    const scoresRes = await fetch(
      `${SUPABASE_URL}/rest/v1/quiz_scores?user_id=in.(${userIdList})&select=user_id,chapter,score,percentage`,
      {
        headers: {
          "apikey": SUPABASE_SERVICE_KEY,
          "Authorization": `Bearer ${SUPABASE_SERVICE_KEY}`
        }
      }
    );
    const allScores = await scoresRes.json();
    const scores = Array.isArray(allScores) ? allScores : [];
    const assessRes = await fetch(
      `${SUPABASE_URL}/rest/v1/assessment_results?user_id=in.(${userIdList})&select=user_id,assessment_type,result_data`,
      {
        headers: {
          "apikey": SUPABASE_SERVICE_KEY,
          "Authorization": `Bearer ${SUPABASE_SERVICE_KEY}`
        }
      }
    );
    const allAssessments = await assessRes.json();
    const assessments = Array.isArray(allAssessments) ? allAssessments : [];
    const leaderboard = profiles.map((profile) => {
      const userScores = scores.filter((s) => s.user_id === profile.id);
      const userAssessments = assessments.filter((a) => a.user_id === profile.id);
      const bestPerUnit = {};
      userScores.filter((s) => ACTIVE_UNITS.includes(s.chapter)).forEach((s) => {
        if (!bestPerUnit[s.chapter] || s.percentage > bestPerUnit[s.chapter]) {
          bestPerUnit[s.chapter] = s.percentage;
        }
      });
      const unitsPassed = Object.values(bestPerUnit).filter((p) => p >= 80).length;
      const bestScores = Object.values(bestPerUnit).sort((a, b) => b - a);
      const best2 = bestScores.slice(0, 2);
      const avgPercentage = best2.length > 0 ? best2.reduce((sum, p) => sum + p, 0) / best2.length : 0;
      const hasScorecard = userAssessments.some((a) => a.assessment_type?.startsWith("10x-scorecard"));
      const hasCognitive = userAssessments.some((a) => a.assessment_type === "where-do-you-sit");
      const scorecardResult = userAssessments.find((a) => a.assessment_type === "10x-scorecard-content");
      const scorecardScore = scorecardResult?.result_data?.average || null;
      const scorecardPoints = scorecardScore ? Math.round(scorecardScore * 20) : 0;
      const cognitivePoints = hasCognitive ? 50 : 0;
      const unitPoints = unitsPassed * 100;
      const engagementPoints = Math.min(userScores.length * 2, 50);
      const totalPoints = scorecardPoints + cognitivePoints + unitPoints + Math.round(avgPercentage) + engagementPoints;
      let displayName;
      if (profile.first_name && profile.last_name) {
        displayName = `${profile.first_name} ${profile.last_name[0]}.`;
      } else if (profile.first_name) {
        displayName = profile.first_name;
      } else {
        const username = profile.email.split("@")[0].replace(/[._]/g, " ");
        displayName = username.split(" ").map((w) => w.charAt(0).toUpperCase() + w.slice(1)).join(" ");
      }
      const isBrianR = profile.email.toLowerCase() === "brian.raver@sap.com";
      const badgeScorecard = isBrianR ? "\u{1F37A}" : "\u{1F4CA}";
      const badgeCognitive = isBrianR ? "\u{1F37A}" : "\u{1F9E0}";
      return {
        displayName,
        unitsPassed,
        totalUnits: ACTIVE_UNITS.length,
        badgeScorecard,
        badgeCognitive,
        quizzesTaken: userScores.length,
        avgPercentage: Math.round(avgPercentage),
        hasScorecard,
        hasCognitive,
        scorecardScore,
        totalPoints,
        joinedAt: profile.created_at
      };
    });
    leaderboard.sort((a, b) => b.totalPoints - a.totalPoints);
    leaderboard.forEach((entry, i) => {
      entry.rank = i + 1;
    });
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        leaderboard,
        totalMembers: profiles.length,
        lastUpdated: (/* @__PURE__ */ new Date()).toISOString()
      })
    };
  } catch (err) {
    console.error("Error:", err);
    return { statusCode: 500, headers, body: JSON.stringify({ error: "Server error", details: err.message }) };
  }
};
